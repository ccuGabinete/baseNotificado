import { defineProperties } from '@electron/internal/common/define-properties'
import { moduleList } from '@electron/internal/sandboxed_renderer/api/module-list'

defineProperties(exports, moduleList)
