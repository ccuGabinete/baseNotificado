---
name: Security report
about: Do not create an issue for security reports, send an email to security@electronjs.org

---

### Notice 

**DO NOT** create an issue for security reports.
Send an email to: **security@electronjs.org**.
