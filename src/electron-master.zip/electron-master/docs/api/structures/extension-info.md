# ExtensionInfo Object

* `name` String
* `version` String
