# BluetoothDevice Object

* `deviceName` String
* `deviceId` String
