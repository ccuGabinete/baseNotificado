# ProtocolResponseUploadData Object

* `contentType` String - MIME type of the content.
* `data` String - Content to be sent.
