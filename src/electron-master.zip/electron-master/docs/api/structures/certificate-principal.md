# CertificatePrincipal Object

* `commonName` String - Common Name.
* `organizations` String[] - Organization names.
* `organizationUnits` String[] - Organization Unit names.
* `locality` String - Locality.
* `state` String - State or province.
* `country` String - Country or region.
