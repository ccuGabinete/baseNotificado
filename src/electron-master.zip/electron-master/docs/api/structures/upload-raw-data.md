# UploadRawData Object

* `type` String - `rawData`.
* `bytes` Buffer - Data to be uploaded.
