# Point Object

* `x` Number
* `y` Number

**Note:** Both `x` and `y` must be whole integers, when providing a point object
as input to an Electron API we will automatically round your `x` and `y` values
to the nearest whole integer.
