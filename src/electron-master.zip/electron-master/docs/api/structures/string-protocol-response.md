# StringProtocolResponse Object

* `mimeType` String (optional) - MIME type of the response.
* `charset` String (optional) - Charset of the response.
* `data` String | null - A string representing the response body.
