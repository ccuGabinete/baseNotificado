# Event Object extends `GlobalEvent`

* `preventDefault` VoidFunction
