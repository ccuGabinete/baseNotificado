# Size Object

* `width` Number
* `height` Number
