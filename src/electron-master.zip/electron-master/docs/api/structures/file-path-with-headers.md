# FilePathWithHeaders Object

* `path` String - The path to the file to send.
* `headers` Record<string, string> (optional) - Additional headers to be sent.
