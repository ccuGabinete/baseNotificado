# MemoryUsageDetails Object

* `count` Number
* `size` Number
* `liveSize` Number
