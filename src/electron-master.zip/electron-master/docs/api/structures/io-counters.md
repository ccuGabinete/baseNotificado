# IOCounters Object

* `readOperationCount` Number - The number of I/O read operations.
* `writeOperationCount` Number - The number of I/O write operations.
* `otherOperationCount` Number - Then number of I/O other operations.
* `readTransferCount` Number - The number of I/O read transfers.
* `writeTransferCount` Number - The number of I/O write transfers.
* `otherTransferCount` Number - Then number of I/O other transfers.
