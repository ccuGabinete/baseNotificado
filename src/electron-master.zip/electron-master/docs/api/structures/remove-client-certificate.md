# RemoveClientCertificate Object

* `type` String - `clientCertificate`.
* `origin` String - Origin of the server whose associated client certificate
  must be removed from the cache.
