# FileFilter Object

* `name` String
* `extensions` String[]
