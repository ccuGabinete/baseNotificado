# SegmentedControlSegment Object

* `label` String (optional) - The text to appear in this segment.
* `icon` NativeImage (optional) - The image to appear in this segment.
* `enabled` Boolean (optional) - Whether this segment is selectable. Default: true.
