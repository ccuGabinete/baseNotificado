# UploadBlob Object

* `type` String - `blob`.
* `blobUUID` String - UUID of blob data to upload.
