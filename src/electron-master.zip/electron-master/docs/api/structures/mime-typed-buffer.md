# MimeTypedBuffer Object

* `mimeType` String - The mimeType of the Buffer that you are sending.
* `data` Buffer - The actual Buffer content.
