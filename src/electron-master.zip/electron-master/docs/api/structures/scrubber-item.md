# ScrubberItem Object

* `label` String (optional) - The text to appear in this item.
* `icon` NativeImage (optional) - The image to appear in this item.
