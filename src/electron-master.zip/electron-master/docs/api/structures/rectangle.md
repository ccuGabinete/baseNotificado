# Rectangle Object

* `x` Number - The x coordinate of the origin of the rectangle (must be an integer).
* `y` Number - The y coordinate of the origin of the rectangle (must be an integer).
* `width` Number - The width of the rectangle (must be an integer).
* `height` Number - The height of the rectangle (must be an integer).
