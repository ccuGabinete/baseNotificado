# IpcMainInvokeEvent Object extends `Event`

* `frameId` Integer - The ID of the renderer frame that sent this message
* `sender` WebContents - Returns the `webContents` that sent the message
