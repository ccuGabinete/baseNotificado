# WebSource Object

* `code` String
* `url` String (optional)
* `startLine` Integer (optional) - Default is 1.
