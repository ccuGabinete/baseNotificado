# ProtocolRequest Object

* `url` String
* `referrer` String
* `method` String
* `uploadData` [UploadData[]](upload-data.md) (optional)
