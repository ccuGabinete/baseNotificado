# InputEvent Object

* `modifiers` String[] (optional) - An array of modifiers of the event, can
  be `shift`, `control`, `ctrl`, `alt`, `meta`, `command`, `cmd`, `isKeypad`,
  `isAutoRepeat`, `leftButtonDown`, `middleButtonDown`, `rightButtonDown`,
  `capsLock`, `numLock`, `left`, `right`.
