# CrashReport Object

* `date` Date
* `id` String
